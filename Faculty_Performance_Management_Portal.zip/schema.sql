CREATE DATABASE IF NOT EXISTS faculty_portal
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE faculty_portal;

CREATE TABLE faculty (
  id INT AUTO_INCREMENT PRIMARY KEY,
  faculty_code VARCHAR(30) NOT NULL UNIQUE,
  full_name VARCHAR(120) NOT NULL,
  email VARCHAR(120) NOT NULL UNIQUE,
  department VARCHAR(100) NOT NULL,
  designation VARCHAR(100) NOT NULL,
  qualification VARCHAR(150),
  date_joined DATE,
  phone VARCHAR(30),
  active BOOLEAN DEFAULT TRUE
);

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(80) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role VARCHAR(20) NOT NULL DEFAULT 'faculty',
  faculty_id INT NULL,
  CONSTRAINT fk_user_faculty FOREIGN KEY (faculty_id) REFERENCES faculty(id)
);

CREATE TABLE attendance (
  id INT AUTO_INCREMENT PRIMARY KEY,
  faculty_id INT NOT NULL,
  attendance_date DATE NOT NULL,
  time_in TIME NULL,
  time_out TIME NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'Present',
  notes VARCHAR(255),
  UNIQUE KEY unique_faculty_day (faculty_id, attendance_date),
  CONSTRAINT fk_attendance_faculty FOREIGN KEY (faculty_id) REFERENCES faculty(id) ON DELETE CASCADE
);

CREATE TABLE leave_request (
  id INT AUTO_INCREMENT PRIMARY KEY,
  faculty_id INT NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  leave_type VARCHAR(40) NOT NULL DEFAULT 'Casual',
  reason TEXT NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'Pending',
  submitted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_leave_faculty FOREIGN KEY (faculty_id) REFERENCES faculty(id) ON DELETE CASCADE
);

CREATE TABLE evaluation (
  id INT AUTO_INCREMENT PRIMARY KEY,
  faculty_id INT NOT NULL,
  evaluation_date DATE NOT NULL,
  teaching_score DECIMAL(5,2) NOT NULL,
  student_feedback DECIMAL(5,2) NOT NULL,
  syllabus_completion DECIMAL(5,2) NOT NULL,
  research_score DECIMAL(5,2) NOT NULL,
  comments TEXT,
  evaluator VARCHAR(120),
  CONSTRAINT fk_evaluation_faculty FOREIGN KEY (faculty_id) REFERENCES faculty(id) ON DELETE CASCADE,
  CHECK (teaching_score BETWEEN 0 AND 100),
  CHECK (student_feedback BETWEEN 0 AND 100),
  CHECK (syllabus_completion BETWEEN 0 AND 100),
  CHECK (research_score BETWEEN 0 AND 100)
);
