# Faculty Performance Management Portal

A Flask web application inspired by the provided faculty management screenshot. It includes role-based login, faculty profiles, attendance, leave requests, performance evaluations, and summary reports.

## Features

- Admin and faculty sign-in
- Dashboard KPIs and department chart
- Faculty directory, search, and profile details
- Daily attendance entry (one record per faculty member per day)
- Leave request submission and admin approval/rejection
- Performance evaluations with a weighted score:
  - Teaching: 35%
  - Student feedback: 25%
  - Syllabus completion: 25%
  - Research: 15%
- Reports table with average evaluation score and attendance rate
- Responsive sidebar UI

## Requirements

- Python 3.10+
- MySQL 8+ (optional for first run; SQLite is used by default)
- A modern browser

## Run locally (quick start with SQLite)

1. Extract the ZIP.
2. Open a terminal in the project folder.
3. Create and activate a virtual environment:

   **Windows**
   ```powershell
   py -m venv .venv
   .venv\Scripts\Activate.ps1
   ```

   **macOS/Linux**
   ```bash
   python3 -m venv .venv
   source .venv/bin/activate
   ```

4. Install packages:
   ```bash
   pip install -r requirements.txt
   ```
5. Start the app:
   ```bash
   python app.py
   ```
6. Open `http://127.0.0.1:5000`.

The app creates its tables and sample records on first run.

## Demo accounts

- **Admin:** `admin` / `Admin@123`
- **Faculty:** `aditi` / `Faculty@123`

Change these passwords and the `SECRET_KEY` before deploying or using real personal data. Demo records are fictional.

## Configure MySQL

1. Run `schema.sql` in MySQL Workbench or the MySQL CLI to create the database and tables.
2. Create a MySQL user and grant access to `faculty_portal`.
3. Set `DATABASE_URL` before running the app.

**Windows PowerShell**
```powershell
$env:DATABASE_URL = "mysql+pymysql://faculty_user:YOUR_PASSWORD@localhost/faculty_portal"
$env:SECRET_KEY = "replace-with-a-long-random-secret"
python app.py
```

**macOS/Linux**
```bash
export DATABASE_URL="mysql+pymysql://faculty_user:YOUR_PASSWORD@localhost/faculty_portal"
export SECRET_KEY="replace-with-a-long-random-secret"
python app.py
```

If using MySQL, the Flask app's SQLAlchemy models create any missing tables automatically. The `schema.sql` file documents the matching schema. For a clean MySQL install, it is also fine to let the app create the tables instead of running the SQL file first.

## Main routes

- `/login` — sign-in
- `/dashboard` — overview
- `/faculty` — faculty directory (admin) or own profile (faculty)
- `/attendance` — attendance entry and history
- `/leave` — leave requests and approval controls
- `/performance` — evaluations and score history
- `/reports` — faculty performance report
- `/schedule` — placeholder schedule page

## Important notes

This is an academic starter project, not a production HR system. Before deployment, add CSRF protection, password change/reset, rate limiting, audit logging, secure HTTPS cookies, database backups, and institutional privacy/security review. Use real faculty data only with permission.
