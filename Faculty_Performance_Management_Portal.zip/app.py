import os
from datetime import date, datetime
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, flash, session
from werkzeug.security import generate_password_hash, check_password_hash
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config["SECRET_KEY"] = os.getenv("SECRET_KEY", "change-this-secret-key-before-deployment")

# Configure MySQL with DATABASE_URL, e.g.:
# mysql+pymysql://faculty_user:your_password@localhost/faculty_portal
# If DATABASE_URL is not set, SQLite is used for easy local testing.
app.config["SQLALCHEMY_DATABASE_URI"] = os.getenv(
    "DATABASE_URL", "sqlite:///faculty_portal.db"
)
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db = SQLAlchemy(app)


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False, default="faculty")
    faculty_id = db.Column(db.Integer, db.ForeignKey("faculty.id"), nullable=True)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


class Faculty(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    faculty_code = db.Column(db.String(30), unique=True, nullable=False)
    full_name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    department = db.Column(db.String(100), nullable=False)
    designation = db.Column(db.String(100), nullable=False)
    qualification = db.Column(db.String(150), default="")
    date_joined = db.Column(db.Date, default=date.today)
    phone = db.Column(db.String(30), default="")
    active = db.Column(db.Boolean, default=True)
    attendance = db.relationship("Attendance", backref="faculty", lazy=True, cascade="all, delete-orphan")
    leaves = db.relationship("LeaveRequest", backref="faculty", lazy=True, cascade="all, delete-orphan")
    evaluations = db.relationship("Evaluation", backref="faculty", lazy=True, cascade="all, delete-orphan")


class Attendance(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    faculty_id = db.Column(db.Integer, db.ForeignKey("faculty.id"), nullable=False)
    attendance_date = db.Column(db.Date, nullable=False, default=date.today)
    time_in = db.Column(db.Time, nullable=True)
    time_out = db.Column(db.Time, nullable=True)
    status = db.Column(db.String(20), nullable=False, default="Present")
    notes = db.Column(db.String(255), default="")
    __table_args__ = (db.UniqueConstraint("faculty_id", "attendance_date", name="unique_faculty_day"),)


class LeaveRequest(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    faculty_id = db.Column(db.Integer, db.ForeignKey("faculty.id"), nullable=False)
    start_date = db.Column(db.Date, nullable=False)
    end_date = db.Column(db.Date, nullable=False)
    leave_type = db.Column(db.String(40), nullable=False, default="Casual")
    reason = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(20), nullable=False, default="Pending")
    submitted_at = db.Column(db.DateTime, default=datetime.utcnow)


class Evaluation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    faculty_id = db.Column(db.Integer, db.ForeignKey("faculty.id"), nullable=False)
    evaluation_date = db.Column(db.Date, nullable=False, default=date.today)
    teaching_score = db.Column(db.Float, nullable=False)
    student_feedback = db.Column(db.Float, nullable=False)
    syllabus_completion = db.Column(db.Float, nullable=False)
    research_score = db.Column(db.Float, nullable=False)
    comments = db.Column(db.Text, default="")
    evaluator = db.Column(db.String(120), default="Administrator")

    @property
    def overall_score(self):
        # Weighted score: teaching 35%, feedback 25%, syllabus 25%, research 15%.
        return round(
            self.teaching_score * .35 +
            self.student_feedback * .25 +
            self.syllabus_completion * .25 +
            self.research_score * .15, 2
        )


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped


def admin_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login"))
        if session.get("role") != "admin":
            flash("Administrator access is required for that action.", "warning")
            return redirect(url_for("dashboard"))
        return view(*args, **kwargs)
    return wrapped


def current_faculty():
    if session.get("role") == "faculty":
        return db.session.get(Faculty, session.get("faculty_id"))
    return None


@app.route("/")
def index():
    if "user_id" in session:
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        user = User.query.filter_by(username=username).first()
        if user and user.check_password(password):
            session.clear()
            session["user_id"] = user.id
            session["username"] = user.username
            session["role"] = user.role
            session["faculty_id"] = user.faculty_id
            flash("Welcome back.", "success")
            return redirect(url_for("dashboard"))
        flash("Invalid username or password.", "danger")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("login"))


@app.route("/dashboard")
@login_required
def dashboard():
    faculty_scope = current_faculty()
    if faculty_scope:
        faculty_list = [faculty_scope]
        attendance_count = Attendance.query.filter_by(faculty_id=faculty_scope.id, status="Present").count()
        leave_pending = LeaveRequest.query.filter_by(faculty_id=faculty_scope.id, status="Pending").count()
        evaluations = Evaluation.query.filter_by(faculty_id=faculty_scope.id).order_by(Evaluation.evaluation_date.desc()).all()
    else:
        faculty_list = Faculty.query.filter_by(active=True).order_by(Faculty.full_name).all()
        attendance_count = Attendance.query.filter_by(attendance_date=date.today(), status="Present").count()
        leave_pending = LeaveRequest.query.filter_by(status="Pending").count()
        evaluations = Evaluation.query.order_by(Evaluation.evaluation_date.desc()).limit(8).all()

    latest_evaluations = evaluations[:8]
    avg_score = round(sum(e.overall_score for e in evaluations) / len(evaluations), 1) if evaluations else 0
    dept_counts = {}
    if not faculty_scope:
        for f in faculty_list:
            dept_counts[f.department] = dept_counts.get(f.department, 0) + 1
    return render_template(
        "dashboard.html", faculty_count=len(faculty_list), attendance_count=attendance_count,
        leave_pending=leave_pending, avg_score=avg_score, latest_evaluations=latest_evaluations,
        dept_labels=list(dept_counts.keys()), dept_values=list(dept_counts.values()),
        faculty_scope=faculty_scope
    )


@app.route("/faculty")
@login_required
def faculty_list():
    if current_faculty():
        return redirect(url_for("faculty_detail", faculty_id=current_faculty().id))
    q = request.args.get("q", "").strip()
    query = Faculty.query
    if q:
        query = query.filter(
            db.or_(Faculty.full_name.ilike(f"%{q}%"), Faculty.faculty_code.ilike(f"%{q}%"),
                   Faculty.department.ilike(f"%{q}%"))
        )
    faculty = query.order_by(Faculty.full_name).all()
    return render_template("faculty.html", faculty=faculty, q=q)


@app.route("/faculty/new", methods=["GET", "POST"])
@admin_required
def faculty_new():
    if request.method == "POST":
        f = Faculty(
            faculty_code=request.form["faculty_code"].strip(),
            full_name=request.form["full_name"].strip(),
            email=request.form["email"].strip(),
            department=request.form["department"].strip(),
            designation=request.form["designation"].strip(),
            qualification=request.form.get("qualification", "").strip(),
            phone=request.form.get("phone", "").strip(),
            date_joined=date.fromisoformat(request.form["date_joined"]) if request.form.get("date_joined") else date.today(),
        )
        db.session.add(f)
        try:
            db.session.commit()
            flash("Faculty member added successfully.", "success")
            return redirect(url_for("faculty_list"))
        except Exception:
            db.session.rollback()
            flash("Could not add faculty. Check that the faculty code and email are unique.", "danger")
    return render_template("faculty_form.html", faculty=None)


@app.route("/faculty/<int:faculty_id>")
@login_required
def faculty_detail(faculty_id):
    faculty = db.session.get(Faculty, faculty_id)
    if not faculty:
        flash("Faculty member not found.", "danger")
        return redirect(url_for("faculty_list"))
    scoped = current_faculty()
    if scoped and scoped.id != faculty.id:
        flash("You can only view your own profile.", "warning")
        return redirect(url_for("dashboard"))
    attendance = Attendance.query.filter_by(faculty_id=faculty.id).order_by(Attendance.attendance_date.desc()).limit(10).all()
    leaves = LeaveRequest.query.filter_by(faculty_id=faculty.id).order_by(LeaveRequest.submitted_at.desc()).limit(5).all()
    evaluations = Evaluation.query.filter_by(faculty_id=faculty.id).order_by(Evaluation.evaluation_date.desc()).limit(5).all()
    return render_template("faculty_detail.html", faculty=faculty, attendance=attendance, leaves=leaves, evaluations=evaluations)


@app.route("/attendance", methods=["GET", "POST"])
@login_required
def attendance_page():
    faculty_scope = current_faculty()
    faculty = [faculty_scope] if faculty_scope else Faculty.query.filter_by(active=True).order_by(Faculty.full_name).all()
    if request.method == "POST":
        faculty_id = faculty_scope.id if faculty_scope else int(request.form["faculty_id"])
        day = date.fromisoformat(request.form.get("attendance_date") or date.today().isoformat())
        status = request.form.get("status", "Present")
        time_in = datetime.strptime(request.form["time_in"], "%H:%M").time() if request.form.get("time_in") else None
        time_out = datetime.strptime(request.form["time_out"], "%H:%M").time() if request.form.get("time_out") else None
        record = Attendance.query.filter_by(faculty_id=faculty_id, attendance_date=day).first()
        if record is None:
            record = Attendance(faculty_id=faculty_id, attendance_date=day)
            db.session.add(record)
        record.status, record.time_in, record.time_out = status, time_in, time_out
        record.notes = request.form.get("notes", "").strip()
        try:
            db.session.commit()
            flash("Attendance saved.", "success")
        except Exception:
            db.session.rollback()
            flash("Unable to save attendance.", "danger")
        return redirect(url_for("attendance_page"))
    query = Attendance.query.order_by(Attendance.attendance_date.desc(), Attendance.id.desc())
    if faculty_scope:
        query = query.filter_by(faculty_id=faculty_scope.id)
    records = query.limit(100).all()
    return render_template("attendance.html", faculty=faculty, records=records, today=date.today().isoformat(), faculty_scope=faculty_scope)


@app.route("/leave", methods=["GET", "POST"])
@login_required
def leave_page():
    faculty_scope = current_faculty()
    if request.method == "POST":
        if faculty_scope:
            faculty_id = faculty_scope.id
        else:
            faculty_id = int(request.form["faculty_id"])
        start = date.fromisoformat(request.form["start_date"])
        end = date.fromisoformat(request.form["end_date"])
        if end < start:
            flash("End date cannot be earlier than start date.", "danger")
            return redirect(url_for("leave_page"))
        leave = LeaveRequest(
            faculty_id=faculty_id, start_date=start, end_date=end,
            leave_type=request.form["leave_type"], reason=request.form["reason"].strip()
        )
        db.session.add(leave)
        db.session.commit()
        flash("Leave request submitted.", "success")
        return redirect(url_for("leave_page"))
    faculty = [faculty_scope] if faculty_scope else Faculty.query.filter_by(active=True).order_by(Faculty.full_name).all()
    query = LeaveRequest.query.order_by(LeaveRequest.submitted_at.desc())
    if faculty_scope:
        query = query.filter_by(faculty_id=faculty_scope.id)
    leaves = query.limit(100).all()
    return render_template("leave.html", faculty=faculty, leaves=leaves, faculty_scope=faculty_scope)


@app.route("/leave/<int:leave_id>/status", methods=["POST"])
@admin_required
def leave_status(leave_id):
    leave = db.session.get(LeaveRequest, leave_id)
    if leave:
        status = request.form.get("status")
        if status in ("Approved", "Rejected", "Pending"):
            leave.status = status
            db.session.commit()
            flash("Leave request status updated.", "success")
    return redirect(url_for("leave_page"))


@app.route("/performance", methods=["GET", "POST"])
@login_required
def performance_page():
    faculty_scope = current_faculty()
    faculty = [faculty_scope] if faculty_scope else Faculty.query.filter_by(active=True).order_by(Faculty.full_name).all()
    if request.method == "POST":
        faculty_id = faculty_scope.id if faculty_scope else int(request.form["faculty_id"])
        try:
            values = [float(request.form[k]) for k in ("teaching_score", "student_feedback", "syllabus_completion", "research_score")]
            if any(v < 0 or v > 100 for v in values):
                raise ValueError()
            evaluation = Evaluation(
                faculty_id=faculty_id, evaluation_date=date.fromisoformat(request.form.get("evaluation_date") or date.today().isoformat()),
                teaching_score=values[0], student_feedback=values[1], syllabus_completion=values[2],
                research_score=values[3], comments=request.form.get("comments", "").strip(),
                evaluator=session.get("username", "Administrator")
            )
            db.session.add(evaluation)
            db.session.commit()
            flash("Performance evaluation saved.", "success")
        except (ValueError, KeyError):
            flash("Scores must be numeric values between 0 and 100.", "danger")
        return redirect(url_for("performance_page"))
    query = Evaluation.query.order_by(Evaluation.evaluation_date.desc())
    if faculty_scope:
        query = query.filter_by(faculty_id=faculty_scope.id)
    evaluations = query.limit(100).all()
    return render_template("performance.html", faculty=faculty, evaluations=evaluations, today=date.today().isoformat(), faculty_scope=faculty_scope)


@app.route("/schedule")
@login_required
def schedule_page():
    return render_template("schedule.html")


@app.route("/reports")
@login_required
def reports_page():
    faculty_scope = current_faculty()
    if faculty_scope:
        faculty = [faculty_scope]
    else:
        faculty = Faculty.query.filter_by(active=True).order_by(Faculty.full_name).all()
    rows = []
    for f in faculty:
        evals = Evaluation.query.filter_by(faculty_id=f.id).all()
        score = round(sum(e.overall_score for e in evals) / len(evals), 2) if evals else 0
        present = Attendance.query.filter_by(faculty_id=f.id, status="Present").count()
        total = Attendance.query.filter_by(faculty_id=f.id).count()
        attendance_pct = round(present * 100 / total, 1) if total else 0
        rows.append({"faculty": f, "score": score, "attendance_pct": attendance_pct, "evaluations": len(evals)})
    rows.sort(key=lambda r: r["score"], reverse=True)
    return render_template("reports.html", rows=rows)


def seed_data():
    if User.query.filter_by(username="admin").first():
        return
    f1 = Faculty(faculty_code="FAC-001", full_name="Dr. Aditi Sharma", email="aditi.sharma@example.edu",
                 department="Computer Science", designation="Associate Professor", qualification="Ph.D. Computer Science",
                 phone="9876543210", date_joined=date(2020, 7, 1))
    f2 = Faculty(faculty_code="FAC-002", full_name="Prof. Rahul Verma", email="rahul.verma@example.edu",
                 department="Management", designation="Assistant Professor", qualification="MBA, UGC-NET",
                 phone="9876543211", date_joined=date(2022, 1, 10))
    f3 = Faculty(faculty_code="FAC-003", full_name="Ms. Neha Singh", email="neha.singh@example.edu",
                 department="Computer Science", designation="Assistant Professor", qualification="M.Tech. Computer Science",
                 phone="9876543212", date_joined=date(2023, 8, 14))
    db.session.add_all([f1, f2, f3])
    db.session.flush()
    admin = User(username="admin", role="admin")
    admin.set_password("Admin@123")
    u1 = User(username="aditi", role="faculty", faculty_id=f1.id)
    u1.set_password("Faculty@123")
    db.session.add_all([admin, u1])
    db.session.add_all([
        Attendance(faculty_id=f1.id, attendance_date=date.today(), status="Present",
                   time_in=datetime.strptime("09:05", "%H:%M").time(), time_out=datetime.strptime("16:30", "%H:%M").time()),
        Attendance(faculty_id=f2.id, attendance_date=date.today(), status="Present",
                   time_in=datetime.strptime("09:15", "%H:%M").time(), time_out=datetime.strptime("16:15", "%H:%M").time()),
        Evaluation(faculty_id=f1.id, evaluation_date=date.today(), teaching_score=91, student_feedback=88,
                   syllabus_completion=95, research_score=82, comments="Strong teaching and course planning."),
        Evaluation(faculty_id=f2.id, evaluation_date=date.today(), teaching_score=84, student_feedback=86,
                   syllabus_completion=80, research_score=75, comments="Good classroom engagement.")
    ])
    db.session.commit()


with app.app_context():
    db.create_all()
    seed_data()


if __name__ == "__main__":
    app.run(debug=True)
